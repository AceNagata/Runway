# Runway — Design System

**Runway** is a shared planning surface for small teams (5–50 people): notes, to-dos, a task
scheduler, a full calendar, task hand-off down a reporting line, notifications, and on-demand
reports. The product's centre of gravity is the **daily home screen** — a motivational quote,
your performance over the last few days, today's task summary, and one primary CTA to start
tracking and taking notes.

Surfaces covered by this system:

| Surface | Description |
| --- | --- |
| Web app | Home, task lists, schedule/calendar, task detail, notes |
| Mobile app | Home, menu grid, task list, task detail, notes |
| Admin / org hierarchy | Reporting tree, delegate & track a task down the line |
| Reports & analytics | Statistic dashboards, per-person productivity |

## Sources

No codebase, Figma file, or brand asset pack was provided. The direction was set from a
questionnaire the client answered, plus eight browser screenshots dropped into `uploads/` of a
public Behance case study — **"Komma© — Notes and Task management. UX UI Design"** (behance.net,
multiple owners). Those screenshots are third-party work used as **mood reference only**:
we borrowed the structural ideas listed under Visual Foundations (near-black stage, one hot
accent, folder-tab cards, low-chroma line charts). Komma's wordmark, its bird mark, its orange
palette, and its literal screens are **not** reproduced anywhere in this system, and Runway is
not affiliated with it.

## Brand direction

- **Name** — Runway. Picked by the client: a runway is the stretch of time you have before something takes off, and the lights that mark it.
- **Personality** — calm, focused, quietly technical. The interface is a dark room with one lit
  surface. It never shouts; the accent does the pointing.
- **Theme** — dark only. There is no light mode and no token scaffolding for one.
- **Voice** — warm second person. "You're all caught up." "You've closed 12 tasks this week."

## Font substitution

⚠️ No brand font files were supplied, so both faces are Google Fonts stand-ins:
**Manrope** for all UI and display type, **JetBrains Mono** for dates, IDs, durations, and
percentages. If Runway has real licensed faces, send the `.woff2` files and we'll swap them
into `tokens/fonts.css` — every consumer picks the change up through `--font-core` /
`--font-mono` with no other edits.

## Logo

⚠️ No logo was provided, and we did not draw one. Wherever a mark belongs, Runway renders the
wordmark in plain type: `Runway` in Manrope 800, `-0.02em` tracking, `--text-strong` — or
`--text-on-accent` when it sits on an ember field. Send artwork and it lands in
`assets/logo.svg`.

## Accent — ember orange

The first pass ran on teal; the client rejected it, and the system now runs on **ember orange
`#FF4D1C`** — which also matches the mood reference. The ramp is `--ember-300` through
`--ember-900`, and every consumer reads it through `--accent` / `--accent-hover` /
`--accent-press` / `--accent-wash`, so a future hue change stays a five-line edit in
`tokens/colors.css`.

Because the accent is warm, the status hues were re-tuned to stay legible beside it: overdue is a
pink-red `#FF3B5C` rather than an orange-red, due is a yellower amber `#FFC53D`, and done is a
cleaner green `#34D399`. Status colour only ever appears as a 3px folder tab, a 6px dot, or a
chart stroke — never as a filled surface — so it never competes with an ember button.

### Note on the namespace

The project could not be renamed away from its original title, so the compiled runtime namespace
is still `CadenceDesignSystem_82aed6`. That is an internal identifier only — nothing user-facing
uses it, and the brand is Runway throughout. Consumers reach components via
`window.CadenceDesignSystem_82aed6.<Component>`.

## Tokens

`styles.css` at the root is an `@import` list only. It reaches:

| File | Holds |
| --- | --- |
| `tokens/fonts.css` | Google Fonts import, `--font-core`, `--font-mono` |
| `tokens/colors.css` | Ink/chalk ramps, accent + status hues, semantic surface/text/line aliases |
| `tokens/typography.css` | Size–line-height–tracking triples and composite `font:` shorthands |
| `tokens/spacing.css` | 4px-base scale, row/control heights, sidebar and panel widths |
| `tokens/radii.css` | 2 → 14px plus pill; semantic control/card/panel aliases |
| `tokens/elevation.css` | Four shadow levels, accent glow, focus ring, accent wash |
| `tokens/motion.css` | Durations, easings, the standard colour transition |

## Visual foundations

**Colour.** A cool near-black stage (`--ink-0` #08090A) with four progressively lighter surface
steps. Chroma is rationed: one ember accent for anything actionable, and three status hues (rose
overdue, amber due, grass done) used only at small sizes — a 2px card tab, a 6px dot, a chart
stroke. Never a filled status card. Nothing on the neutral ramp carries hue beyond a faint cool
cast, so the accent always wins the eye.

**Type.** Manrope everywhere, tightening as it grows (`-0.02em` at display, 0 at body). Body is
14px/1.5. Eyebrow labels are 10px, `0.14em` tracked, uppercase, `--text-faint` — used for column
headers and section kickers. JetBrains Mono at 12px carries every number a user might compare:
times, durations, dates, percentages, IDs, `@handles`.

**Spacing & layout.** 4px base, density 6/10 — generous around cards (16–24px), tight inside list
rows (44px tall, 36px compact). The app is a fixed 224px sidebar (collapsing to 56px), an optional
64px rail, and a fluid centre; contextual panels are a fixed 360px right-hand column. Sidebar,
top bar, and the primary CTA are fixed; only the centre column scrolls.

**Backgrounds.** No photography, no illustration, no repeating pattern, no full-bleed imagery.
The stage is flat `--ink-0`. The single permitted gradient is `--wash-accent`: a soft radial
ember bloom, ≤16% alpha, behind a hero or an active chart — never a corner-to-corner gradient and
never purple.

**Cards.** Borderless. Definition comes from a lighter fill (`--surface-card` on
`--surface-app`), `--shadow-2`, a 1px inner top highlight, and a 10px radius. The one motif
lifted from the reference: a **folder tab** — a 2–3px accent or status bar clipped to the card's
top-left or top-right corner, marking category or urgency. Radii: 4px controls, 10px cards,
14px panels, pill for chips and avatars.

**Borders.** Used as dividers, not containers: `--line-hairline` (6% white) between list rows,
`--line-soft` (10%) for input edges and panel seams, `--line-strong` (16%) only on a focused or
selected element. No card ever gets a full border.

**Shadows.** Four levels, always paired with an inner top highlight because pure shadow reads
as nothing on near-black. Level 1 rows, 2 cards, 3 popovers and dropdowns, 4 modals. Inner
shadow is decorative only at level ≥1's highlight — no inset-pressed treatments.

**Transparency & blur.** Sparingly. `backdrop-filter: blur(20px)` on exactly three things: the
fixed top bar over scrolled content, modal scrims (`rgba(8,9,10,.72)`), and popovers overlapping
dense data. Everywhere else surfaces are opaque so text stays crisp.

**Motion.** Subtle: fades and 150ms colour transitions (`--dur-fast`, `--ease-standard`).
Enter animations fade + 4px rise over 200ms. No bounce, no spring, no scale-in modals, no
skeleton shimmer. Checking a task off is the one flourish: strike-through wipes left-to-right
over 200ms, then the row fades to 40% and settles.

**Hover.** Surfaces lighten one ink step (`--surface-hover`); text goes `--text-muted` →
`--text-body`; the accent lightens to `--accent-hover` (never darkens — on dark UI, darkening
reads as disabled). Icon-only controls gain a `--surface-hover` plate.

**Press.** Colour only — accent drops to `--accent-press`. No transform, no shrink. Scale on
press reads as toy-like against this system's stillness.

**Focus.** Always visible, never a colour swap: `--ring-focus` — a 2px stage-coloured gap then a
2px `--focus-ring` ember ring.

**Data viz.** Single-hue. Line charts are a 1.5px accent stroke over a ≤14% accent area fill,
axis labels in mono `--text-faint`, no gridlines beyond a single hairline baseline. Gauges are
an accent arc on an `--ink-3` track. Never multi-colour categorical palettes.

**Imagery.** Only user-supplied avatars. Treated cool and slightly desaturated to sit in the
dark room; cropped to a pill. No stock photography, no grain overlay, no duotone.

## Content fundamentals

**Voice — warm second person.** The product addresses the user as *you* and refers to itself
rarely and never as *I*. Empty and complete states are reassuring, not congratulatory:
"You're all caught up." / "Nothing due today — enjoy it." / "You've closed 12 of 14 tasks this
week." Avoid "Great job!", "Awesome!", and exclamation marks generally — one per screen at most,
and only in a genuine success state.

**Casing.** Sentence case for everything a human reads: buttons ("Add task", "Start tracking"),
headings ("Today's tasks"), menu items ("Org chart"). `UPPERCASE` is reserved for 10px eyebrow
labels and table column headers. Never Title Case A Whole Sentence.

**Buttons are verb-first and specific:** "Add task", "Assign to Maya", "Generate report",
"Send invite" — never "Submit", "OK", or "Click here". The home CTA is "Start tracking".

**Numbers are exact and unqualified.** "3 overdue", "12 hours this week", "67% productivity" —
not "a few overdue" or "~12 hours". Counts always carry their noun.

**Dates are relative near the present, absolute beyond it:** Today, Tomorrow, Fri — then
27.04.2026 in mono. Times are 09:00 – 11:00 with an en dash.

**Notifications lead with the actor:** "Maya assigned you Q3 roadmap review." /
"Design School is due in 2 hours." Second sentence maximum, no preamble.

**Errors state the problem and the fix, no apology:** "This task needs a due date before you can
schedule it." Not "Oops! Something went wrong."

**No emoji, anywhere** — not in UI, not in copy, not in empty states, not as project markers.
No illustration either; empty states are a muted icon at 40% opacity plus one line of type.

**Hierarchy language is plain, not corporate:** "Assign", "Hand off", "Reports to", "Your team" —
never "cascade", "resource", "leverage", or "reporting line" in user-facing copy.

## Iconography

⚠️ **Substitution flagged.** No icon set was provided. Runway uses **Lucide** (CDN,
`lucide@0.469.0`) — chosen because the reference screenshots use a thin, rounded, outline-only
set, which Lucide matches closely at 1.5px stroke.

Rules: outline only, never filled. `stroke-width: 1.5`, round caps and joins, `currentColor`.
Sizes 16px (inline with body / list rows), 20px (sidebar, toolbars), 24px (mobile tab bar and
menu grid). Default colour `--text-muted`, `--text-body` on hover, `--accent` when the item is
active. Icons never appear without a text label except in a 44px-minimum icon button with an
accessible name. No emoji, no unicode glyphs pressed into service as icons, no PNG icons, and
no hand-drawn SVG — if a glyph is missing from Lucide, ask before inventing one.

## Intentional additions

- **`Icon`** (`assets/icons/icon.js`) — a thin wrapper that renders a named Lucide path at
  1.5px stroke in `currentColor`. Not a source-defined component; added because every other
  component takes icon nodes as props and the kits needed one consistent way to make them.
  It is deliberately *not* a bundled design-system component — it's a helper the cards and kits load.

## Index

**Root**

| Path | What it is |
| --- | --- |
| `styles.css` | The single entry point consumers link |
| `readme.md` | This file — brand, content and visual foundations |
| `SKILL.md` | Agent Skills front-matter so this folder works in Claude Code |
| `thumbnail.html` | The homepage tile |
| `tokens/` | Seven token files — see the Tokens table above |
| `assets/icons/icon.js` | Lucide path map + the `Icon` helper |
| `guidelines/` | 16 foundation specimen cards |
| `components/` | 15 primitives in four groups |
| `ui_kits/` | Two product recreations |
| `templates/` | One starting template — the app shell |

**Components** — each with `.jsx`, `.d.ts`, `.prompt.md`, and one card per directory.

| Group | Components |
| --- | --- |
| `components/core/` | Button, IconButton, Card, Badge, Tag, Avatar |
| `components/forms/` | Input, Select, Checkbox, Radio + RadioGroup, Switch |
| `components/navigation/` | Tabs |
| `components/feedback/` | Dialog, Toast, Tooltip |

**UI kits**

| Path | Surface | Screens |
| --- | --- | --- |
| `ui_kits/web/` | Web app, 1440×900 | Home, Tasks, Schedule, Notes, Task detail, Team hierarchy, Reports |
| `ui_kits/mobile/` | Mobile app, 390×844 | Home, Tasks, Schedule, Menu |

Admin/org-hierarchy and reports & analytics are covered as the **Team** and **Reports** screens
inside the web kit rather than as separate kits — they are views of the same app, not separate
products.

**Foundation cards** — `guidelines/`: surfaces, accent, status & priority, text-on-dark (Colors);
display & headings, body & labels, mono (Type); scale, list row in use, radii, elevation (Spacing);
folder tab, wordmark, motion, interaction states, data viz (Brand).

**Templates**

| Path | What it gives you |
| --- | --- |
| `templates/app-screen/` | The dark app shell — sidebar, blurred top bar, stat tiles and a task list — as an editable starting point. `screenTitle` is tweakable. |

## Not built

- No marketing website. The brief listed four surfaces and none of them was a public site; say the
  word and it's the next kit.
- No slide template — no deck was provided to copy a style from.
- No email templates.
