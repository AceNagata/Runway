# Handoff: Runway — notes and task management app

## Overview

Runway is a shared planning surface for small teams (5–50 people). It carries notes,
to-dos, a task scheduler, a calendar, task hand-off down a reporting line, notifications,
and on-demand reports. Its centre of gravity is the **daily home screen**: a greeting and
quote, recent performance, today's task summary, and one primary action to start tracking.

This bundle contains the written product spec and the complete visual design system.
Build the application from both.

## About the design files

The files here are **design references**, not production code to copy.

- `reference/Runway Engineering Spec.dc.html` is a written specification rendered as a
  printable HTML document. It is the requirements document — read its prose, ignore its
  markup. It is not a screen design.
- `design-system/` is the real, authoritative visual system: CSS custom properties for
  colour, type, spacing, radii, elevation, and motion. **Use these tokens directly.** They
  are plain CSS variables and drop into any framework.

Your task is to implement Runway in a real codebase using the target environment's
established patterns and libraries. If no codebase exists yet, choose the framework
yourself — the tokens are framework-agnostic.

## Fidelity

**Mixed, and it matters which is which:**

- **Design tokens: high fidelity.** Colours, type scale, spacing, radii, shadows and
  motion values are final. Match them exactly.
- **Screen layouts: specified in prose, not drawn.** No pixel-perfect screen mockups exist
  in this bundle. Layout rules (sidebar widths, row heights, panel widths, what scrolls and
  what is fixed) are given below and in the design system readme, and they are binding — but
  the exact arrangement of content within a screen is yours to compose within those rules.

Do not invent colours, fonts, or spacing values outside the token set.

---

## Product specification

### 1. Why it exists

Teams at this size run their week across three disconnected tools: a notes app, a task
list, and a calendar. The cost is not storage — it is reconciliation. A note taken in a
meeting becomes a task nobody schedules; a task assigned in chat never lands in anyone's
day; a manager asking "where did that end up" has to look in three places.

Runway collapses the three into one object graph. A note can produce a task, a task
occupies time on a calendar, and a task can be handed to someone else without losing the
record of who held it before.

**Design consequence:** every feature must be reachable from home in one action, and every
feature must be able to report its state back to home in a single line.

### 2. Core features

#### 2.1 Notes

Free-form documents owned by a user, optionally shared with the team. The capture
surface — the thing open during a meeting — so it must accept text with no setup: no title
required, no folder required, no save action.

- Autosave on a debounce; never an unsaved state the user has to think about.
- Any line in a note can be promoted to a task in place. The task keeps a back-reference to
  its source note, and the note line reflects the task's completion state.
- Notes are searchable by body text alongside tasks in one result set — the user does not
  choose which index to search.

#### 2.2 Tasks

The central object. Fields: title, optional body, owner, optional due date-time, status,
history. Everything else in the product is a view over tasks.

- Status is derived where possible: a task past its due date with no completion is overdue
  without anyone setting it so.
- Completion is optimistic in the UI and reconciled with the server afterwards — checking
  off must never wait on a round trip.
- A task with no due date is valid and lives in an unscheduled bucket; it cannot be placed
  on the calendar until it has one.
- History is append-only: created, assigned, re-assigned, scheduled, completed, re-opened.
  This is what makes hand-off auditable.

#### 2.3 Scheduler and calendar

Two presentations of one dataset, not two features.

- A scheduled task occupies a start and end time on a day. Overlaps are permitted and
  rendered side by side, not blocked.
- Dragging a task in the calendar edits its schedule directly; same write as editing it in
  the detail panel.
- Time tracking attaches to a task, not to a calendar block: a user can start tracking a
  task that was never scheduled.

#### 2.4 Notifications

Three event classes only: something was assigned to you; something you own is approaching
or past its due time; something you handed off changed state. Lead with the actor, two
sentences maximum. Read-state tracked per user, clearable in bulk.

### 3. Daily home screen

Default route after authentication and the target of the wordmark. It answers one
question — *what is today* — above the fold on both web and mobile. Four regions, fixed
vertical order:

1. **Greeting and quote.** User's name plus a motivational quote. The quote is decorative,
   rotates daily, loads independently, and must never delay the regions below it. Its
   absence is not an error state.
2. **Recent performance.** Compact read of the last several days: tasks closed, time
   tracked, a single-hue trend line. A summary, not a dashboard — it links through to
   Reports rather than expanding in place.
3. **Today's task summary.** Tasks due or scheduled today, grouped by status, each row
   checkable inline. Overdue items from previous days surface at the top; they are the only
   past-dated content home ever shows.
4. **Primary action.** One fixed CTA — "Start tracking" — reachable without scrolling. It
   starts a timer against the user's next scheduled task, or opens task selection if there
   is none.

**Empty states carry weight here** because a healthy user hits them often. A day with
nothing due is a success, not a void. Each region has its own empty treatment, and they
must not all fire at once on a first-run account — first run gets a distinct onboarding pass.

**Performance requirement:** home renders from cached local state immediately on load and
reconciles with the server in the background. Never a full-screen loading state for a
returning user.

### 4. Task hand-off and org hierarchy

Every member has exactly one manager and zero or more direct reports, forming a tree. The
tree is the permission model, not just a diagram: a user can see and act on the tasks of
anyone below them, and cannot see sideways or upward.

Hand-off moves a task's ownership down that tree:

- A task can only be handed to a direct or indirect report of the current owner.
- Hand-off does not clear the originator. The chain of custody stays on the task and is
  visible to everyone in it, so the person who raised the work can still track it after two
  hops.
- The receiving user is notified and the task appears in their list immediately. **No accept
  step** — refusal is a conversation, not a state machine.
- Due dates travel with the task. A hand-off never silently extends a deadline.
- Deleting a user re-parents their reports to their manager and reassigns their open tasks
  upward, never into an orphan state.

The admin surface renders this tree and is the only place membership and manager
relationships can be edited. Tree edits are transactional — a cycle must be impossible to
create, and the operation is rejected rather than partially applied.

### 5. Reports and analytics

Generated on demand over a chosen date range and subject: yourself, one report, or your
whole subtree. Access follows the same tree rule as §4.

Measures are derived from task history, never entered by hand:

- Tasks closed and tasks opened over the range
- Time tracked, split by task and by day
- On-time completion rate against due dates
- Current open load, split by overdue, due, and unscheduled

Charts are single-hue and comparative across **time only, not across people** — the product
does not rank teammates against each other.

Reports must be computable client-side for a single user's own range so the personal case is
instant; team-wide ranges may go to the server and may show a loading state.

### 6. Screens and surfaces

Three clients over one API.

**Web** (complete product) — fixed sidebar, fixed top bar, scrolling centre column.
Contextual detail opens in a fixed right-hand panel rather than a new route, so the list
behind it stays in place. Screens: home, tasks, schedule, notes, task detail, team, reports.
Sidebar collapses to icons on narrow viewports. Only the centre column scrolls.

**Mobile** — home, tasks, schedule, notes, plus a menu grid for everything else. Task detail
is a full route, not a panel. Reports and the team tree are read-only on mobile. Every
interactive target at least 44px.

**Admin** — org tree, member invitations, role assignment. Shares the web shell rather than
being a separate application; reached from the sidebar by permitted users. Destructive
operations require confirmation that states its consequence.

### 7. Cross-cutting requirements

- **Offline tolerance.** Reads come from local state first. Writes queue and replay; the
  user is told when something is unsynced but never blocked from working.
- **One source of truth per object.** A task edited in the calendar, list, detail panel, or a
  note issues the same mutation, and every open view updates from it.
- **Time zones.** Timestamps stored UTC, rendered in the viewing user's zone. A due date is a
  date-*time*, not a date, so hand-off across zones does not move a deadline.
- **Accessibility.** Full keyboard reach for list navigation, task completion, and panel
  dismissal. Status is never carried by colour alone — every status colour pairs with a
  label or a shape.
- **Dark theme only.** No light mode and no token scaffolding for one. Do not build
  components that branch on theme.

---

## Design tokens

Load `design-system/styles.css` (an `@import` list reaching the seven token files) and read
every value through the CSS custom properties. Do not hard-code the hex values below —
they are listed so you can verify your build.

### Colour

Dark only. Cool near-black stage, one ember accent for anything actionable, three status
hues used only at small sizes.

**Neutral ramp**

| Token | Value | | Token | Value |
| --- | --- | --- | --- | --- |
| `--ink-0` | `#08090A` | | `--chalk-0` | `#FFFFFF` |
| `--ink-1` | `#0D0F11` | | `--chalk-1` | `#E8EDEF` |
| `--ink-2` | `#141719` | | `--chalk-2` | `#A8B2B7` |
| `--ink-3` | `#1C2023` | | `--chalk-3` | `#6D777C` |
| `--ink-4` | `#262B2F` | | `--chalk-4` | `#4A5257` |
| `--ink-5` | `#343A3F` | | | |

**Accent — ember orange**

`--ember-300` `#FFB59B` · `--ember-400` `#FF7847` · `--ember-500` `#FF4D1C` ·
`--ember-600` `#D93A0E` · `--ember-700` `#A32B08` · `--ember-900` `#3D1105`

**Status**

`--amber-400` `#FFC53D` / `--amber-600` `#B8861C` ·
`--rose-400` `#FF3B5C` / `--rose-600` `#B92038` ·
`--grass-400` `#34D399` / `--grass-600` `#1E7F5C`

**Semantic aliases — always consume these, not the ramps**

| Alias | Maps to |
| --- | --- |
| `--surface-app` | `--ink-0` |
| `--surface-panel` | `--ink-1` |
| `--surface-card` | `--ink-2` |
| `--surface-raised` / `--surface-hover` | `--ink-3` |
| `--surface-input` | `--ink-2` |
| `--surface-active` | `--ink-4` |
| `--text-strong` / `--text-body` / `--text-muted` / `--text-faint` | `--chalk-0` / `-1` / `-2` / `-3` |
| `--text-on-accent` | `#1F0A03` |
| `--line-hairline` / `--line-soft` / `--line-strong` | `rgba(255,255,255,.06)` / `.10` / `.16` |
| `--accent` / `--accent-hover` / `--accent-press` / `--accent-wash` | `--ember-500` / `-400` / `-600` / `-900` |
| `--focus-ring` | `--ember-400` |
| `--status-overdue` / `--status-due` / `--status-done` / `--status-idle` | `--rose-400` / `--amber-400` / `--grass-400` / `--chalk-3` |
| `--priority-high` / `--priority-mid` / `--priority-low` | `--rose-400` / `--amber-400` / `--chalk-3` |

**Rules.** Status colour appears only as a 2–3px folder tab, a 6px dot, or a chart stroke —
**never a filled status surface.** Nothing on the neutral ramp carries hue beyond a faint
cool cast, so the accent always wins the eye.

### Typography

Two Google Fonts stand-ins (no brand faces were supplied): **Manrope** for all UI and
display type via `--font-core`, **JetBrains Mono** for numbers via `--font-mono`. If real
licensed faces arrive later, they swap in `tokens/fonts.css` and every consumer picks it up.

| Role | Size / line-height / tracking | Weight |
| --- | --- | --- |
| Display | 44px / 1.05 / -0.02em | 700 |
| H1 | 30px / 1.15 / -0.015em | 700 |
| H2 | 22px / 1.25 / -0.01em | 600 |
| H3 | 17px / 1.35 / -0.005em | 600 |
| Body | 14px / 1.5 | 400 |
| Small | 13px / 1.45 | 500 (label) |
| XS / caption | 11px / 1.35 | 400 |
| Mono data | 12px / 1.4 / 0.01em | 500 |
| Eyebrow | 10px, 0.14em tracking, uppercase | — |

Weights: `--fw-regular` 400, `--fw-medium` 500, `--fw-semibold` 600, `--fw-bold` 700,
`--fw-black` 800.

Composite shorthands are available: `--text-display`, `--text-heading-1`,
`--text-heading-2`, `--text-heading-3`, `--text-body-default`, `--text-label`,
`--text-caption`, `--text-data`.

**JetBrains Mono at 12px carries every number a user might compare** — times, durations,
dates, percentages, IDs, `@handles`. Eyebrow labels are `--text-faint`, uppercase, used for
column headers and section kickers.

### Spacing and layout

4px base, density 6/10.

`--sp-1` 2 · `--sp-2` 4 · `--sp-3` 6 · `--sp-4` 8 · `--sp-5` 12 · `--sp-6` 16 ·
`--sp-7` 20 · `--sp-8` 24 · `--sp-9` 32 · `--sp-10` 40 · `--sp-11` 56 · `--sp-12` 80 (px)

| Token | Value | Use |
| --- | --- | --- |
| `--row-h` | 44px | List row |
| `--row-h-compact` | 36px | Dense list row |
| `--control-h` | 34px | Default control |
| `--control-h-sm` / `-lg` | 28px / 40px | Small / large control |
| `--sidebar-w` | 224px | Web sidebar |
| `--sidebar-w-collapsed` | 56px | Collapsed sidebar |
| `--rail-w` | 64px | Optional icon rail |
| `--panel-w` | 360px | Right-hand contextual panel |
| `--gutter-app` | 20px | App gutter |
| `--gutter-card` | 16px | Card padding |
| `--tap-min` | 44px | Minimum touch target |

Generous around cards (16–24px), tight inside list rows.

### Radii

`--r-xs` 2 · `--r-sm` 4 · `--r-md` 6 · `--r-lg` 10 · `--r-xl` 14 · `--r-pill` 999 (px)

Semantic: `--radius-control` 4px · `--radius-card` 10px · `--radius-panel` 14px ·
`--radius-chip` pill.

### Elevation

Four levels, each pairing a downward shadow with a 1px top inner highlight — on near-black,
shadow alone reads as nothing.

```css
--shadow-1: 0 1px 2px rgba(0,0,0,.55), inset 0 1px 0 rgba(255,255,255,.03);
--shadow-2: 0 2px 8px rgba(0,0,0,.6),  inset 0 1px 0 rgba(255,255,255,.04);
--shadow-3: 0 8px 24px -4px rgba(0,0,0,.7), inset 0 1px 0 rgba(255,255,255,.05);
--shadow-4: 0 20px 48px -8px rgba(0,0,0,.8), inset 0 1px 0 rgba(255,255,255,.06);
--shadow-accent: 0 4px 16px -2px rgba(255,77,28,.38);
--ring-focus: 0 0 0 2px var(--surface-app), 0 0 0 4px var(--focus-ring);
--wash-accent: radial-gradient(120% 90% at 50% 0%, rgba(255,77,28,.16) 0%, transparent 70%);
```

Level 1 rows · 2 cards · 3 popovers and dropdowns · 4 modals.

### Motion

`--dur-fast` 150ms · `--dur-base` 200ms · `--dur-slow` 320ms ·
`--ease-standard` `cubic-bezier(.4,0,.2,1)` · `--ease-out` `cubic-bezier(0,0,.2,1)` ·
`--ease-in` `cubic-bezier(.4,0,1,1)`

Ready-made: `--transition-color` (colour, background, border, box-shadow at fast/standard)
and `--transition-fade`.

---

## Component and interaction rules

These are binding — they are what makes the product feel like one thing.

**Cards are borderless.** Definition comes from a lighter fill (`--surface-card` on
`--surface-app`), `--shadow-2`, the 1px inner top highlight, and a 10px radius. No card ever
gets a full border.

**The folder tab** is the one signature motif: a 2–3px accent or status bar clipped to a
card's top-left or top-right corner, marking category or urgency.

**Borders are dividers, not containers.** `--line-hairline` between list rows,
`--line-soft` for input edges and panel seams, `--line-strong` only on a focused or selected
element.

**Backgrounds.** No photography, illustration, pattern, or full-bleed imagery. The stage is
flat `--ink-0`. The only permitted gradient is `--wash-accent`, behind a hero or an active
chart — never corner-to-corner.

**Transparency and blur.** `backdrop-filter: blur(20px)` on exactly three things: the fixed
top bar over scrolled content, modal scrims (`rgba(8,9,10,.72)`), and popovers overlapping
dense data. Everything else is opaque so text stays crisp.

**Hover.** Surfaces lighten one ink step to `--surface-hover`; text goes `--text-muted` →
`--text-body`; the accent *lightens* to `--accent-hover` — never darkens, which reads as
disabled on dark UI. Icon-only controls gain a `--surface-hover` plate.

**Press.** Colour only — accent drops to `--accent-press`. No transform, no shrink.

**Focus.** Always visible, never a colour swap: `--ring-focus` (a 2px stage-coloured gap,
then a 2px ember ring).

**Motion.** Fades and 150ms colour transitions. Enter animations fade + 4px rise over 200ms.
No bounce, no spring, no scale-in modals, no skeleton shimmer. **Checking a task off is the
one flourish:** strike-through wipes left-to-right over 200ms, then the row fades to 40% and
settles.

**Data viz.** Single-hue. Line charts are a 1.5px accent stroke over a ≤14% accent area fill,
axis labels in mono `--text-faint`, no gridlines beyond a single hairline baseline. Gauges
are an accent arc on an `--ink-3` track. Never a multi-colour categorical palette.

**Imagery.** Only user-supplied avatars, treated cool and slightly desaturated, cropped to a
pill. No stock photography, no grain, no duotone.

---

## Content and copy rules

- **Warm second person.** The product addresses the user as *you* and never refers to itself
  as *I*. Empty and complete states are reassuring, not congratulatory: "You're all caught
  up." / "Nothing due today — enjoy it." Avoid "Great job!" and exclamation marks — one per
  screen at most, and only in a genuine success state.
- **Sentence case** for everything a human reads: buttons, headings, menu items. UPPERCASE is
  reserved for 10px eyebrow labels and table column headers. Never Title Case A Sentence.
- **Buttons are verb-first and specific:** "Add task", "Assign to Maya", "Generate report",
  "Send invite" — never "Submit", "OK", or "Click here". The home CTA is "Start tracking".
- **Numbers are exact and unqualified,** and carry their noun: "3 overdue", "12 hours this
  week", "67% productivity".
- **Dates are relative near the present, absolute beyond it:** Today, Tomorrow, Fri — then
  `27.04.2026` in mono. Times use an en dash: `09:00 – 11:00`.
- **Notifications lead with the actor:** "Maya assigned you Q3 roadmap review."
- **Errors state the problem and the fix, no apology:** "This task needs a due date before
  you can schedule it." Not "Oops! Something went wrong."
- **Hierarchy language is plain:** "Assign", "Hand off", "Reports to", "Your team" — never
  "cascade", "resource", or "leverage".
- **No emoji anywhere.** No illustration either — empty states are a muted icon at 40%
  opacity plus one line of type.

## Iconography

**Lucide** (`lucide@0.469.0`), chosen as a substitute because no icon set was supplied.

Outline only, never filled. `stroke-width: 1.5`, round caps and joins, `currentColor`.
Sizes: 16px inline with body and list rows, 20px sidebar and toolbars, 24px mobile tab bar
and menu grid. Default `--text-muted`, `--text-body` on hover, `--accent` when active.
Icons never appear without a text label except in a 44px-minimum icon button with an
accessible name. No emoji, no unicode glyphs as icons, no PNG icons, no hand-drawn SVG — if
a glyph is missing from Lucide, ask before inventing one.

## Logo

No logo artwork exists. Render the wordmark in plain type: `Runway` in Manrope 800,
`-0.02em` tracking, `--text-strong` — or `--text-on-accent` on an ember field.

## Assets

None beyond the token CSS in this bundle. Fonts load from Google Fonts (see
`design-system/tokens/fonts.css`). Icons come from the Lucide package. Avatars are
user-supplied at runtime.

---

## Open questions — decide these before building the affected areas

1. Do notes support rich structure (headings, checklists, embeds), or plain text with task
   promotion only?
2. Is collaborative editing of a shared note concurrent, or last-write-wins with a lock?
3. Can a task be handed *sideways* to a peer with a manager's approval, or is downward-only
   final?
4. Does time tracking allow manual entry after the fact, or only a live timer?
5. Are reports exportable, and in what format?
6. What is the recurrence model for repeating tasks — or are they out of scope for v1?
7. Which platforms does mobile cover, and is it native or a web shell?
8. What is the backend and auth story? Nothing in this spec assumes one.

Ask the product owner rather than assuming. Where you must proceed, pick the simplest option
that does not foreclose the others, and note the assumption in code.

## Files in this bundle

| Path | What it is |
| --- | --- |
| `README.md` | This document — self-sufficient, implement from it |
| `design-system/styles.css` | Single entry point; `@import`s the token files |
| `design-system/tokens/*.css` | Colour, type, spacing, radii, elevation, motion, fonts |
| `design-system/readme.md` | Full design-system rationale and foundations |
| `reference/Runway Engineering Spec.dc.html` | The spec as a printable document (source of §1–7 above) |
| `reference/doc-page.js` | Print shell used by that document only — not app code |
